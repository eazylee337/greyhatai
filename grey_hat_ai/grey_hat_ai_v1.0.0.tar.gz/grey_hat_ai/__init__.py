"""
Grey Hat AI - Advanced Cybersecurity AI Framework with GUI and Voice Integration

This module provides the main entry point for the Grey Hat AI application.
"""

__version__ = "1.0.0"
__author__ = "Manus AI"

