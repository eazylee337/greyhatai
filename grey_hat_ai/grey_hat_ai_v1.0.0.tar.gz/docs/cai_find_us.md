# Find Us

We're excited to connect with you! Join our community through any of the following channels:

* [GitHub](https://github.com/aliasrobotics/cai)

* [Discord Community](https://discord.gg/v3SAXXg5)

* [Linkedin Group](https://www.linkedin.com/groups/10086397/)

* [Alias Robotics](https://aliasrobotics.com)