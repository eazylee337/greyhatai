# `OpenAI Chat Completions model`

::: cai.sdk.agents.models.openai_chatcompletions
