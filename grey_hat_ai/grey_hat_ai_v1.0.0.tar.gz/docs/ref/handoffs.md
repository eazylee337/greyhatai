# `Handoffs`

::: cai.sdk.agents.handoffs
