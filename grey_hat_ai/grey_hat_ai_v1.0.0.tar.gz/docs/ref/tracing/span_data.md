# `Span data`

::: cai.sdk.agents.tracing.span_data
