# `Scope`

::: cai.sdk.agents.tracing.scope
