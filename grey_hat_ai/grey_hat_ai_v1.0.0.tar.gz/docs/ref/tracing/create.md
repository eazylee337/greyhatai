# `Creating traces/spans`

::: cai.sdk.agents.tracing.create
