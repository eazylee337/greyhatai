# `Streaming events`

::: cai.sdk.agents.stream_events
