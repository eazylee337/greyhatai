# `Exceptions`

::: cai.sdk.agents.exceptions
