# `Function schema`

::: cai.sdk.agents.function_schema
