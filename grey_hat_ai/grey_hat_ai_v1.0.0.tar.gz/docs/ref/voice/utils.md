# `Utils`

::: cai.sdk.agents.voice.utils
