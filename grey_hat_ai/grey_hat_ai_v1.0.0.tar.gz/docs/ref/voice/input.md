# `Input`

::: cai.sdk.agents.voice.input
