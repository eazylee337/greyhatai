# `Result`

::: cai.sdk.agents.voice.result
