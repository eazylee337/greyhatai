# `Exceptions`

::: cai.sdk.agents.voice.exceptions
